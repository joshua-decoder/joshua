import java.math.*;
import java.util.*;
import java.io.*;

public class FirstLastMatch extends EvaluationMetric
{
  /********************************************
    private data members for this error metric
  ********************************************/


  private String[][] firstRefWords;
  private String[][] lastRefWords;
    // first/lastRefWords[i][r] stores the first/last word
    // in the r'th reference of the i'th sentence

  /*
     You already have access to these data members of the parent
     class (EvaluationMetric):
         int numSentences;
           number of sentences in the MERT set
         int refsPerSen;
           number of references per sentence
         String[][] refSentences;
           refSentences[i][r] stores the r'th reference of the i'th
           source sentence (both indices are 0-based)
  */
  /********************************************
  ********************************************/

  public FirstLastMatch(String[] Metric_options)
  {
    initialize(); // set the data members of the metric
  }

  protected void initialize()
  {
    metricName = "FLM";
    toBeMinimized = false;
    suffStatsCount = 2;

    set_FL_words();
  }

  public double bestPossibleScore() { return 1.0; }
  public double worstPossibleScore() { return 0.0; }

  private void set_FL_words()
  {
    firstRefWords = new String[numSentences][refsPerSen];
    lastRefWords = new String[numSentences][refsPerSen];
      // first/lastRefWords[i][r] stores the first/last word
      // in the r'th reference of the i'th sentence

    for (int i = 0; i < numSentences; i++) {
      for (int r = 0; r < refsPerSen; r++) {
        String[] refWords = refSentences[i][r].split(" ");
        firstRefWords[i][r] = refWords[0];
        lastRefWords[i][r] = refWords[refWords.length-1];
      }
    }
  }

  public int[] suffStats(String cand_str, int i)
  {
    int[] stats = new int[suffStatsCount];

    int count = 0;

    String[] candWords = cand_str.split(" ");

    String FW = candWords[0];
    for (int r = 0; r < refsPerSen; r++) {
      if (FW.equals(firstRefWords[i][r])) {
        count++;
        break;
      }
    }

    String LW = candWords[candWords.length-1];
    for (int r = 0; r < refsPerSen; r++) {
      if (LW.equals(lastRefWords[i][r])) {
        count++;
        break;
      }
    }

    stats[0] = count;
    stats[1] = 2;

    return stats;
  }

  public double score(int[] stats)
  {
    if (stats.length != suffStatsCount) {
      System.out.println("Mismatch between stats.length and suffStatsCount (" + stats.length + " vs. " + suffStatsCount + ")");
      System.exit(1);
    }

    double sc = 0.0;

    sc = stats[0] / (double)stats[1];

    return sc;
  }

  public void printDetailedScore_fromStats(int[] stats, boolean oneLiner)
  {
    // Basic output:
    // System.out.println(metricName + " = " + score(stats));

    // More detailed output:
    if (oneLiner) {
      System.out.println("FLM = " + stats[0] + "/" + stats[1] + " = " + f4.format(stats[0]/(double)stats[1]));
    } else {
      System.out.println("# matches = " + stats[0]);
      System.out.println("max # matches = " + stats[1]);
      System.out.println("FLM = " + stats[0] + "/" + stats[1] + " = " + f4.format(stats[0]/(double)stats[1]));
    }
  }

}
